﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using AppSettingsPoC.Views;
using AppSettingsPoC.Models;
using System.Reflection;
using System.IO;
using Newtonsoft.Json;

namespace AppSettingsPoC
{
    public partial class App : Application
    {

        public App()
        {
            InitializeComponent();

            MainPage = new HomePage();
        }

        private static AppSettings appSettings;
        public static AppSettings AppSettings
        {
            get
            {
                if (appSettings == null)
                    LoadAppSettings();

                return appSettings;
            }
        }
        private static void LoadAppSettings()
        {
#if RELEASE
            var appSettingsResourceStream = Assembly.GetAssembly(typeof(AppSettings)).GetManifestResourceStream("AppSettingsPoC.Configuration.appsettings.release.json");
#else
            var appSettingsResourceStream = Assembly.GetAssembly(typeof(AppSettings)).GetManifestResourceStream("AppSettingsPoC.Configuration.appsettings.debug.json");
#endif
            if(appSettingsResourceStream == null)
                return;

            using (var streamReader = new StreamReader(appSettingsResourceStream))
            {
                var jsonString = streamReader.ReadToEnd();
                appSettings = JsonConvert.DeserializeObject<AppSettings>(jsonString);
            }
        }


        protected override void OnStart()
        {
            // Handle when your app starts
        }

        protected override void OnSleep()
        {
            // Handle when your app sleeps
        }

        protected override void OnResume()
        {
            // Handle when your app resumes
        }
    }
}
