﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AppSettingsPoC.ViewModels
{
    public class HomeViewModel
    {

        public string WelcomeText
        {
            get
            { 
                return App.AppSettings.WelcomeText;
            }
        }
    }
}
