﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AppSettingsPoC.Models
{
    public class AppSettings
    {
        public string WelcomeText { get; set; }
    }
}
