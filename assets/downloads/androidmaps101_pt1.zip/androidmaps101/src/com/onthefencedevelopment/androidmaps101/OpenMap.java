package com.onthefencedevelopment.androidmaps101;

import android.os.Bundle;
import com.google.android.maps.MapView;

// Add the following three import statements
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;

public class OpenMap extends MapActivity {
	
	private MapController mapController;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
		// Get Mapping Controllers etc
		MapView mapView = (MapView) findViewById(R.id.map_view);
		mapController = mapView.getController();

		// Centre on Exmouth
		mapController.setCenter(new GeoPoint((int) (50.634955 * 1E6), 
				                                       (int) (-3.409753 * 1E6)));
		mapController.setZoom(11);
		mapView.setBuiltInZoomControls(true);
    }

	@Override
	protected boolean isRouteDisplayed() {
		// TODO Auto-generated method stub
		return false;
	}
}