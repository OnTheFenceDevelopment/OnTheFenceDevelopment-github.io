package com.onthefencedevelopment.androidmaps101;

import com.google.android.maps.Overlay;

public class DemoOverlay extends Overlay {

}
