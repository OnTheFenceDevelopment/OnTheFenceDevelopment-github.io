﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

namespace JQueryAJAX
{
    public partial class CoordinateHandler: System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.Form["Latitude"] != null && Request.Form["Longitude"] != null)
            {
                try
                {
                    // Lat/Long have been specified - save them
                    // using (StreamWriter sw = File.CreateText("coordinates.txt")) // For testing failure
                    using (StreamWriter sw = File.CreateText(Server.MapPath("/") + "coordinates.txt"))
                    {
                        sw.WriteLine("Latitude: " + Request.Form["Latitude"]);
                        sw.WriteLine("Longitude: " + Request.Form["Longitude"]);
                        sw.Flush();
                        sw.Close();
                    }
                }
                catch (Exception)
                {
                    
                    throw;
                }
            }
        }
    }
}