package com.onthefencedevelopment.androidmaps101;

import java.util.ArrayList;
import java.util.Iterator;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Point;
import android.graphics.RectF;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.Projection;

public class DemoOverlay extends Overlay {

	private ArrayList<GeoPoint> _displayedMarkers;
	private LinearLayout _bubbleLayout;

	@Override
	public void draw(Canvas canvas, MapView mapView, boolean shadow) {

		super.draw(canvas, mapView, shadow);

		Projection projection = mapView.getProjection();

		int latSpan = mapView.getLatitudeSpan();
		int lngSpan = mapView.getLongitudeSpan();
		GeoPoint mapCenter = mapView.getMapCenter();
		int mapLeftGeo = mapCenter.getLongitudeE6() - (lngSpan / 2);
		int mapRightGeo = mapCenter.getLongitudeE6() + (lngSpan / 2);

		int mapTopGeo = mapCenter.getLatitudeE6() - (latSpan / 2);
		int mapBottomGeo = mapCenter.getLatitudeE6() + (latSpan / 2);

		_displayedMarkers = new ArrayList<GeoPoint>();

		GeoPoint geoPoint = this.getSampleLocation();

		if ((geoPoint.getLatitudeE6() > mapTopGeo && geoPoint.getLatitudeE6() < mapBottomGeo)
				&& (geoPoint.getLongitudeE6() > mapLeftGeo && geoPoint.getLongitudeE6() < mapRightGeo)) {

			Point myPoint = new Point();
			projection.toPixels(geoPoint, myPoint);

			Bitmap marker = BitmapFactory.decodeResource(mapView.getContext().getResources(), R.drawable.markerblue);

			canvas.drawBitmap(marker, myPoint.x - 15, myPoint.y - 30, null);

			_displayedMarkers.add(geoPoint); // Add this line ....

		}
	}

	@Override
	public boolean onTap(GeoPoint p, MapView mapView) {

		// If a bubble is currently displayed then clear it..
		if (_bubbleLayout != null) {
			mapView.removeView(_bubbleLayout);
		}

		if (performHitTest(mapView, p)) {

			// Get instance of the Bubble Layout ...
			LayoutInflater inflater = (LayoutInflater) mapView.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			_bubbleLayout = (LinearLayout) inflater.inflate(R.layout.bubble, mapView, false);

			// .. configure its layout parameters
			MapView.LayoutParams params = new MapView.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, p,
					MapView.LayoutParams.BOTTOM_CENTER);

			_bubbleLayout.setLayoutParams(params);

			// Locate the TextView
			TextView locationNameText = (TextView) _bubbleLayout.findViewById(R.id.locationName);
			
			// Set the Text
			locationNameText.setText(getSampleText());

			// Add the view to the Map
			mapView.addView(_bubbleLayout);
			
			// Animate the map to center on the location
			mapView.getController().animateTo(p);
		}

		return true;

	};

	private boolean performHitTest(MapView mapView, GeoPoint geo) {

		// Declare locals
		RectF hitTestRecr = new RectF();
		Point tappedCoordinates = new Point();
		Point locationCoordinates = new Point();

		// Instantiate a projection instance to convert Lat/Long map coordinates to x/y screen coordinates.
		Projection projection = mapView.getProjection();
		projection.toPixels(geo, tappedCoordinates);

		// Configure our hit box - 50px x 50px
		hitTestRecr.set(-25, -25, 25, 25);
		// ... and offset it to center on the tapped location
		hitTestRecr.offset(tappedCoordinates.x, tappedCoordinates.y);

		// Iterate over displayed markers
		Iterator<GeoPoint> iterator = _displayedMarkers.iterator();

		while (iterator.hasNext()) {
			// Get next geo location ...
			GeoPoint testLocation = iterator.next();
			// ... convert to screen coordinates ...
			projection.toPixels(testLocation, locationCoordinates);
			// .. and see if they fall within the hit box
			if (hitTestRecr.contains(locationCoordinates.x, locationCoordinates.y)) {
				// .. if it does then return true to indicate a hit
				return true;
			}
		}

		return false;
	}

	private GeoPoint getSampleLocation() {

		// Create GeoPoint to secret location....
		GeoPoint sampleGeoPoint = new GeoPoint((int) (56.27058500725475 * 1E6), (int) (-2.6984095573425293 * 1E6));

		return sampleGeoPoint;
	}

	private String getSampleText() {
		return "Scottish Secret Bunker";
	}

}
