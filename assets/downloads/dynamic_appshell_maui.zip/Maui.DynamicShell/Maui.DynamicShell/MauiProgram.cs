﻿using CommunityToolkit.Maui;
using Microsoft.Extensions.Logging;

namespace Maui.DynamicShell;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>()
            .UseMauiCommunityToolkit()
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
            });

        builder.Services.AddSingleton<MainPage>();
        builder.Services.AddSingleton<AppShellViewModel>();
        
        builder.Services.AddSingleton<PageOneViewModel>();
        builder.Services.AddSingleton<PageOne>();
        
        builder.Services.AddSingleton<PageTwoViewModel>();
        builder.Services.AddSingleton<PageTwo>();
        
        builder.Services.AddSingleton<LoginPage>();
        builder.Services.AddSingleton<LoginViewModel>();
        
        return builder.Build();
    }
}