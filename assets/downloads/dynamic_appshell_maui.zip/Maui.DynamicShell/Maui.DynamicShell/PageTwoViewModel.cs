namespace Maui.DynamicShell;

public class PageTwoViewModel
{
    public string Title => "Page Two";
}