using CommunityToolkit.Mvvm.Input;

namespace Maui.DynamicShell;

public partial class LoginViewModel
{
    private readonly AppShellViewModel _appShellViewModel;

    public LoginViewModel(AppShellViewModel appShellViewModel)
    {
        _appShellViewModel = appShellViewModel;
    }
    
    [RelayCommand]
    private async Task Login()
    {
        _appShellViewModel.IsLoggedIn = true;
        await Shell.Current.GoToAsync($"//{nameof(MainPage)}");
    }
}