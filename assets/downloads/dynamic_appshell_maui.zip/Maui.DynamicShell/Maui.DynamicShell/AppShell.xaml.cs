﻿namespace Maui.DynamicShell;

public partial class AppShell : Shell
{
    public AppShell(AppShellViewModel viewModel)
    {
        InitializeComponent();
        
        Routing.RegisterRoute(nameof(PageOne), typeof(PageOne));
        Routing.RegisterRoute(nameof(PageTwo), typeof(PageTwo));
        Routing.RegisterRoute(nameof(LoginPage), typeof(LoginPage));
        
        BindingContext = viewModel;
    }
}