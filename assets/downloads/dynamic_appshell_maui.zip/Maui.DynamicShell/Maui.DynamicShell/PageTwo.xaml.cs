namespace Maui.DynamicShell;

public partial class PageTwo : ContentPage
{
    public PageTwo(PageTwoViewModel viewModel)
    {
        BindingContext = viewModel;
        InitializeComponent();
    }
}