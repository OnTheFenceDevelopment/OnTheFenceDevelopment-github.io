namespace Maui.DynamicShell;

public class PageOneViewModel
{
    public string Title => "Page One";
}