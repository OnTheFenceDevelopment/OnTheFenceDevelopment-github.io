﻿namespace Maui.DynamicShell;

public partial class MainPage : ContentPage
{
    int count = 0;

    private AppShellViewModel appShellViewModel;
    
    public MainPage(AppShellViewModel vm)
    {
        appShellViewModel = vm;
        InitializeComponent();
    }

    private void OnCounterClicked(object sender, EventArgs e)
    {
        count++;

        if (count == 1)
            CounterBtn.Text = $"Clicked {count} time";
        else
            CounterBtn.Text = $"Clicked {count} times";
        
        SemanticScreenReader.Announce(CounterBtn.Text);
    }
}