namespace Maui.DynamicShell;

public partial class PageOne : ContentPage
{
    public PageOne(PageOneViewModel viewModel)
    {
        BindingContext = viewModel;
        InitializeComponent();
    }
}