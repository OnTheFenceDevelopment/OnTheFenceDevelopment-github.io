using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace Maui.DynamicShell;

public partial class AppShellViewModel : ObservableObject
{
    [ObservableProperty] 
    private bool _isLoggedIn;

    [RelayCommand]
    private async Task PageOne()
    {
        Shell.Current.FlyoutIsPresented = false;
        await Shell.Current.GoToAsync(nameof(PageOne));
    }
    
    [RelayCommand]
    private async Task PageTwo()
    {
        Shell.Current.FlyoutIsPresented = false;
        await Shell.Current.GoToAsync(nameof(PageTwo));
    }
    
    [RelayCommand]
    private async Task Login()
    {
        Shell.Current.FlyoutIsPresented = false;
        await Shell.Current.GoToAsync($"///{nameof(LoginPage)}");
    }
    
    [RelayCommand]
    private async Task Logout()
    {
        IsLoggedIn = false;
        Shell.Current.FlyoutIsPresented = false;
    }
}